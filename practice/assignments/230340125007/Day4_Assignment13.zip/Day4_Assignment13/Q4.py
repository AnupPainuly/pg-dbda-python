"""
Q4.Write a program to display following menu and do the following:
1. Add new city and trees commonly found in the city.
2. Display all cities and the list of trees for all cities.
3. Display list of trees of a particular city.
---- Accept a city from user search city and if found display list of trees otherwise
---- Display message not found
4. Display cities which have the given tree.
---- Accept a tree name from user and display all cities in which the tree is found.
5. Delete city ---- Accept city from user and delete the city if found.
---- Prompt user before deletion
6. Modify tree list
---- Accept city and trees to be added in the city. if city exist add trees at the end of the list
---- Otherwise add city and list
7. Exit
"""

def add_city_trees(dictionary):
    city = input("Enter city name: ")
    trees = input("Enter trees commonly found in the city (separated by commas): ").split(",")
    dictionary[city] = trees
    print("City and trees added successfully.")


def display_all_cities_trees(dictionary):
    print("List of cities and their trees:")
    for city, trees in dictionary.items():
        print(city + ": " + ", ".join(trees))


def display_city_trees(dictionary):
    city = input("Enter city name to display trees: ")
    if city in dictionary:
        print("City:", city)
        print("Trees:", ", ".join(dictionary[city]))
    else:
        print("City not found.")


def display_cities_with_tree(dictionary):
    tree = input("Enter tree name to display cities: ")
    cities = [city for city, trees in dictionary.items() if tree in trees]
    if cities:
        print("Cities with tree", tree + ":")
        for city in cities:
            print(city)
    else:
        print("No cities found with the given tree.")


def delete_city(dictionary):
    city = input("Enter city name to delete: ")
    if city in dictionary:
        confirm = input("Do you want to delete " + city + " and its trees? (y/n): ")
        if confirm.lower() == 'y':
            del dictionary[city]
            print("City and trees deleted successfully.")
    else:
        print("City not found.")


def modify_tree_list(dictionary):
    city = input("Enter city name to modify tree list: ")
    trees = input("Enter trees to add to the city (separated by commas): ").split(",")
    if city in dictionary:
        dictionary[city].extend(trees)
        print("Tree list modified successfully.")
    else:
        dictionary[city] = trees
        print("City and tree list added successfully.")


def display_menu():
    print("\nMenu:")
    print("1. Add new city and trees commonly found in the city")
    print("2. Display all cities and the list of trees for all cities")
    print("3. Display list of trees of a particular city")
    print("4. Display cities which have the given tree")
    print("5. Delete city")
    print("6. Modify tree list")
    print("7. Exit")


cities_trees = {}

while True:
    display_menu()
    choice = input("Enter your choice (1-7): ")

    if choice == '1':
        add_city_trees(cities_trees)
    elif choice == '2':
        display_all_cities_trees(cities_trees)
    elif choice == '3':
        display_city_trees(cities_trees)
    elif choice == '4':
        display_cities_with_tree(cities_trees)
    elif choice == '5':
        delete_city(cities_trees)
    elif choice == '6':
        modify_tree_list(cities_trees)
    elif choice == '7':
        print("Exiting the program...")
        break
    else:
        print("Invalid choice! Please try again.")

