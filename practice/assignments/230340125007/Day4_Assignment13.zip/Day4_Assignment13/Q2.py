"""
Q2.Given a dictionary of students and their favourite colours:
people={'Arham':'Blue','Lisa':'Yellow',''Vinod:'Purple','Jenny':'Pink'}
1. Find out how many students are in the list
2. Change Lisa’s favourite colour
3. Remove 'Jenny' and her favourite colour
4. Sort and print students and their favourite colours alphabetically by name
"""
people = {'Arham': 'Blue', 'Lisa': 'Yellow', 'Vinod': 'Purple', 'Jenny': 'Pink'}

# Find out how many students are in the list
num_students = len(people)
print("Number of students:", num_students)

# Change Lisa's favorite color
people['Lisa'] = 'Green'
print("Updated favorite color of Lisa:", people['Lisa'])

# Remove Jenny and her favorite color
del people['Jenny']
print("Updated dictionary after removing Jenny:", people)

# Sort and print students and their favorite colors alphabetically by name
sorted_people = sorted(people.items(), key=lambda x: x[0])  # Sort by name (key)
for student, color in sorted_people:
    print(student, "-", color)
