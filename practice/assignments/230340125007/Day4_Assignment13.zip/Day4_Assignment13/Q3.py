"""
Q3.Write a menu driven program to practice Dictionary functions.
Write a program to accept name of a person and their vehicle and store it in a dictionary.
Ask user if they want to continue to accept multiple values.
Display following menu:
1. Add new person name and a vehicle name.
2. Delete a person name and vehicle name from the dictionary.
----Accept person name from user.
----Check whether person name exists in the dictionary.
----If exists show person name and vehicle name to the user.
----Confirm for deletion, if user enters y
then delete otherwise no. Display appropriate message.
3. Modify vehicle name for the person
----Accept a person name from user.
----Check whether the person’s name exists.
----If the name exists, show the person’s name and vehicle name to user.
Ask for new value and then overwrite the old value.
4. Search vehicle for the given person’s name.
5. Search list of people, who have given a vehicle
6. Display all person names.
7. Display all vehicle names.
8 Exit
"""
def add_person_vehicle(dictionary):
    person = input("Enter person's name: ")
    vehicle = input("Enter vehicle name: ")
    dictionary[person] = vehicle
    print("Person and vehicle added successfully.")


def delete_person_vehicle(dictionary):
    person = input("Enter person's name to delete: ")
    if person in dictionary:
        print("Person:", person)
        print("Vehicle:", dictionary[person])
        confirm = input("Do you want to delete this person and vehicle? (y/n): ")
        if confirm.lower() == 'y':
            del dictionary[person]
            print("Person and vehicle deleted successfully.")
    else:
        print("Person not found in the dictionary.")


def modify_vehicle_name(dictionary):
    person = input("Enter person's name to modify vehicle name: ")
    if person in dictionary:
        print("Person:", person)
        print("Current Vehicle:", dictionary[person])
        new_vehicle = input("Enter new vehicle name: ")
        dictionary[person] = new_vehicle
        print("Vehicle name modified successfully.")
    else:
        print("Person not found in the dictionary.")


def search_vehicle_by_person(dictionary):
    person = input("Enter person's name to search vehicle: ")
    if person in dictionary:
        print("Person:", person)
        print("Vehicle:", dictionary[person])
    else:
        print("Person not found in the dictionary.")


def search_people_by_vehicle(dictionary):
    vehicle = input("Enter vehicle name to search people: ")
    people = [person for person, v in dictionary.items() if v == vehicle]
    if people:
        print("People with vehicle", vehicle + ":")
        for person in people:
            print(person)
    else:
        print("No people found with the given vehicle.")


def display_all_people(dictionary):
    print("List of all people:")
    for person in dictionary:
        print(person)


def display_all_vehicles(dictionary):
    print("List of all vehicles:")
    for vehicle in dictionary.values():
        print(vehicle)


def display_menu():
    print("\nMenu:")
    print("1. Add new person name and vehicle name")
    print("2. Delete a person name and vehicle name from the dictionary")
    print("3. Modify vehicle name for a person")
    print("4. Search vehicle for a given person's name")
    print("5. Search list of people who have a given vehicle")
    print("6. Display all person names")
    print("7. Display all vehicle names")
    print("8. Exit")


people_vehicles = {}

while True:
    display_menu()
    choice = input("Enter your choice (1-8): ")

    if choice == '1':
        add_person_vehicle(people_vehicles)
    elif choice == '2':
        delete_person_vehicle(people_vehicles)
    elif choice == '3':
        modify_vehicle_name(people_vehicles)
    elif choice == '4':
        search_vehicle_by_person(people_vehicles)
    elif choice == '5':
        search_people_by_vehicle(people_vehicles)
    elif choice == '6':
        display_all_people(people_vehicles)
    elif choice == '7':
        display_all_vehicles(people_vehicles)
    elif choice == '8':
        print("Exiting the program...")
        break
    else:
        print("Invalid choice! Please try again.")

