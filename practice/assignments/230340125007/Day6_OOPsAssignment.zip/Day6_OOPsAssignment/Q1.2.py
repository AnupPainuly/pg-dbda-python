"""
Q1.2 Write a menu driven program to maintain student information. for every student store studetid,sname, and m1,m2,m3 marks for 3 subject. also store gpa in student class, add a function in student class to return GPA of a student
calculateGPA()
gpa=(1/3)*m1+(1/2)*m2+(1/4)*m3
Create an array to store Multiple students.
1. Display All Student
2. Search by id
3. Search by name
4. calculate GPA of a student
5. Exit
"""
class Student:
    def __init__(self, student_id, name, marks):
        self.student_id = student_id
        self.name = name
        self.marks = marks
        self.gpa = self.calculate_gpa()

    def calculate_gpa(self):
        m1, m2, m3 = self.marks
        gpa = (1/3) * m1 + (1/2) * m2 + (1/4) * m3
        return gpa

# Create an empty list to store student objects
students = []

# Function to display all students
def display_all_students():
    if not students:
        print("No students found.")
        return

    print("Student Information:")
    for student in students:
        print(f"Student ID: {student.student_id}")
        print(f"Name: {student.name}")
        print(f"Marks: {student.marks}")
        print(f"GPA: {student.gpa}")
        print("--------------------")

# Function to search by ID
def search_by_id(student_id):
    for student in students:
        if student.student_id == student_id:
            print(f"Student ID: {student.student_id}")
            print(f"Name: {student.name}")
            print(f"Marks: {student.marks}")
            print(f"GPA: {student.gpa}")
            return

    print("Student not found.")

# Function to search by name
def search_by_name(name):
    for student in students:
        if student.name.lower() == name.lower():
            print(f"Student ID: {student.student_id}")
            print(f"Name: {student.name}")
            print(f"Marks: {student.marks}")
            print(f"GPA: {student.gpa}")
            return

    print("Student not found.")

# Function to calculate GPA of a student
def calculate_gpa_of_student(student_id):
    for student in students:
        if student.student_id == student_id:
            print(f"Student ID: {student.student_id}")
            print(f"Name: {student.name}")
            print(f"Marks: {student.marks}")
            print(f"GPA: {student.gpa}")
            return

    print("Student not found.")

# Adding sample student data
students.append(Student("101", "Raju", [85, 90, 75]))
students.append(Student("102", "Shyam", [95, 80, 92]))
students.append(Student("103", "Babu Rao", [78, 88, 85]))

while True:
    print("\n-- Student Information System --")
    print("1. Display All Students")
    print("2. Search by ID")
    print("3. Search by Name")
    print("4. Calculate GPA of a Student")
    print("5. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        display_all_students()

    elif choice == "2":
        student_id = input("Enter Student ID: ")
        search_by_id(student_id)

    elif choice == "3":
        name = input("Enter Student Name: ")
        search_by_name(name)

    elif choice == "4":
        student_id = input("Enter Student ID: ")
        calculate_gpa_of_student(student_id)

    elif choice == "5":
        print("Exiting the program...")
        break

    else:
        print("Invalid choice!")
