"""
Write a python program to store information of your friends
id,name,lastname,hobbies,mobno,email,bdate,address
note: hobbies- a friend may have multiple hobbies
Accept all friends details and store it in a list
And do the following.
1. Display All Friend
2. Search by id
3. Search by name
4. Display all friend with a particular hobby
5. Exit
"""

class Friend:
    def __init__(self, id, name, lastname, hobbies, mobno, email, bdate, address):
        self.id = id
        self.name = name
        self.lastname = lastname
        self.hobbies = hobbies
        self.mobno = mobno
        self.email = email
        self.bdate = bdate
        self.address = address

class FriendManager:
    def __init__(self):
        self.friends = []

    def addFriend(self, friend):
        self.friends.append(friend)
        print("Friend added successfully!")

    def displayAllFriends(self):
        print("All Friends:")
        for friend in self.friends:
            self.displayFriend(friend)
            print()

    def searchById(self, id):
        for friend in self.friends:
            if friend.id == id:
                print("Friend found:")
                self.displayFriend(friend)
                return
        print("Friend not found!")

    def searchByName(self, name):
        found = False
        for friend in self.friends:
            if friend.name.lower() == name.lower():
                print("Friend found:")
                self.displayFriend(friend)
                found = True
        if not found:
            print("Friend not found!")

    def displayByHobby(self, hobby):
        found = False
        print(f"Friends with hobby '{hobby}':")
        for friend in self.friends:
            if hobby.lower() in [h.lower() for h in friend.hobbies]:
                self.displayFriend(friend)
                found = True
        if not found:
            print("No friends found with the given hobby.")

    def displayFriend(self, friend):
        print(f"ID: {friend.id}")
        print(f"Name: {friend.name} {friend.lastname}")
        print(f"Hobbies: {', '.join(friend.hobbies)}")
        print(f"Mobile Number: {friend.mobno}")
        print(f"Email: {friend.email}")
        print(f"Birthdate: {friend.bdate}")
        print(f"Address: {friend.address}")

# Create an instance of the FriendManager class
manager = FriendManager()

# Accept friend details and store them in the manager
while True:
    print("\n-- Friend Management System --")
    print("1. Add Friend")
    print("2. Display All Friends")
    print("3. Search Friend by ID")
    print("4. Search Friend by Name")
    print("5. Display Friends by Hobby")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        id = input("Enter ID: ")
        name = input("Enter Name: ")
        lastname = input("Enter Last Name: ")
        hobbies = input("Enter Hobbies (comma-separated): ").split(",")
        mobno = input("Enter Mobile Number: ")
        email = input("Enter Email: ")
        bdate = input("Enter Birthdate: ")
        address = input("Enter Address: ")

        friend = Friend(id, name, lastname, hobbies, mobno, email, bdate, address)
        manager.addFriend(friend)

    elif choice == "2":
        manager.displayAllFriends()

    elif choice == "3":
        id = input("Enter ID to search: ")
        manager.searchById(id)

    elif choice == "4":
        name = input("Enter Name to search: ")
        manager.searchByName(name)

    elif choice == "5":
        hobby = input("Enter Hobby to search: ")
        manager.displayByHobby(hobby)

    elif choice == "6":
        print("Exiting the program...")
        break

    else:
        print("Invalid choice! Please try again.")
