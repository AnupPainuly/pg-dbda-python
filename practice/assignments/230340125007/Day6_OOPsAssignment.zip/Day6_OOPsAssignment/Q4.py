"""
Q4.Write a program to store information about accounts.
For every account store acno,name,balance,interest_rate, min_balance,pin number.
There are 3 types of accounts
Saving account, current account, Demat account
For saving account store debit card number and cheque book number, its interest rate is 0.04, and min balance is 15000 , for current account store numberof transactions its interest rate is 0.01, and min balance is 1000, Demat account store commission per transaction and shares name and quantity. its interest rate is 0.10, and min balance is 20000
Add the functions add new account, change pin number, check balance, withdraw amount, deposit amount. For every transaction validate account number and pin number
Handle the exception for withdraw and deposit amount cannot be negative
"""
class Account:
    def __init__(self, acno, name, balance, interest_rate, min_balance, pin):
        self.acno = acno
        self.name = name
        self.balance = balance
        self.interest_rate = interest_rate
        self.min_balance = min_balance
        self.pin = pin

    def check_balance(self):
        return self.balance

    def change_pin(self, old_pin, new_pin):
        if self.pin == old_pin:
            self.pin = new_pin
            print("Pin number changed successfully!")
        else:
            print("Invalid pin number. Pin number not changed.")

    def withdraw_amount(self, amount, pin):
        if amount < 0:
            print("Amount cannot be negative.")
            return

        if self.pin != pin:
            print("Invalid pin number.")
            return

        if self.balance - amount < self.min_balance:
            print("Insufficient balance.")
            return

        self.balance -= amount
        print("Amount withdrawn successfully.")

    def deposit_amount(self, amount, pin):
        if amount < 0:
            print("Amount cannot be negative.")
            return

        if self.pin != pin:
            print("Invalid pin number.")
            return

        self.balance += amount
        print("Amount deposited successfully.")


class SavingAccount(Account):
    def __init__(self, acno, name, balance, pin, debit_card_number, cheque_book_number):
        interest_rate = 0.04
        min_balance = 15000
        super().__init__(acno, name, balance, interest_rate, min_balance, pin)
        self.debit_card_number = debit_card_number
        self.cheque_book_number = cheque_book_number


class CurrentAccount(Account):
    def __init__(self, acno, name, balance, pin, number_of_transactions):
        interest_rate = 0.01
        min_balance = 1000
        super().__init__(acno, name, balance, interest_rate, min_balance, pin)
        self.number_of_transactions = number_of_transactions


class DematAccount(Account):
    def __init__(self, acno, name, balance, pin, commission_per_transaction, shares):
        interest_rate = 0.10
        min_balance = 20000
        super().__init__(acno, name, balance, interest_rate, min_balance, pin)
        self.commission_per_transaction = commission_per_transaction
        self.shares = shares


# Create an empty list to store accounts
accounts = []

while True:
    print("\n-- XYZ Bank --")
    print("1. Add New Account")
    print("2. Check Balance")
    print("3. Change PIN Number")
    print("4. Withdraw Amount")
    print("5. Deposit Amount")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("Account Types:")
        print("1. Saving Account")
        print("2. Current Account")
        print("3. Demat Account")

        account_type = input("Enter the account type (1-3): ")

        acno = input("Enter Account Number: ")
        name = input("Enter Name: ")
        balance = float(input("Enter Balance: "))
        pin = input("Enter PIN Number: ")

        if account_type == "1":
            debit_card_number = input("Enter Debit Card Number: ")
            cheque_book_number = input("Enter Cheque Book Number: ")
            account = SavingAccount(acno, name, balance, pin, debit_card_number, cheque_book_number)
        elif account_type == "2":
            number_of_transactions = int(input("Enter Number of Transactions: "))
            account = CurrentAccount(acno, name, balance, pin, number_of_transactions)
        elif account_type == "3":
            commission_per_transaction = float(input("Enter Commission per Transaction: "))
            shares = input("Enter Shares Name and Quantity: ")
            account = DematAccount(acno, name, balance, pin, commission_per_transaction, shares)
        else:
            print("Invalid account type!")
            continue

        accounts.append(account)
        print("Account added successfully.")

    elif choice == "2":
        acno = input("Enter Account Number: ")
        pin = input("Enter PIN Number: ")

        for account in accounts:
            if account.acno == acno:
                if account.pin == pin:
                    print(f"Account Balance: {account.check_balance()}")
                else:
                    print("Invalid PIN Number.")
                break
        else:
            print("Account not found.")

    elif choice == "3":
        acno = input("Enter Account Number: ")
        pin = input("Enter Current PIN Number: ")
        new_pin = input("Enter New PIN Number: ")

        for account in accounts:
            if account.acno == acno:
                account.change_pin(pin, new_pin)
                break
        else:
            print("Account not found.")

    elif choice == "4":
        acno = input("Enter Account Number: ")
        pin = input("Enter PIN Number: ")
        amount = float(input("Enter Amount to Withdraw: "))

        for account in accounts:
            if account.acno == acno:
                account.withdraw_amount(amount, pin)
                break
        else:
            print("Account not found.")

    elif choice == "5":
        acno = input("Enter Account Number: ")
        pin = input("Enter PIN Number: ")
        amount = float(input("Enter Amount to Deposit: "))

        for account in accounts:
            if account.acno == acno:
                account.deposit_amount(amount, pin)
                break
        else:
            print("Account not found.")

    elif choice == "6":
        print("Exiting the program...")
        break

    else:
        print("Invalid choice!")
