"""
Q1.1 Write a program to create a class song add songid,lyrics,singer name,
create SongService class add function to
addsong() to accept a song details and store it in array
displayAllsongs---- to display all songs
displayByActor(String name) ---- display all songs of a particular singer, pass singername as
-----a parameter to the function
"""

class Song:
    def __init__(self, song_id, lyrics, singer_name):
        self.song_id = song_id
        self.lyrics = lyrics
        self.singer_name = singer_name

class SongService:
    def __init__(self):
        self.songs = []

    def addsong(self, song_id, lyrics, singer_name):
        song = Song(song_id, lyrics, singer_name)
        self.songs.append(song)

    def displayAllsongs(self):
        print("All Songs:")
        for song in self.songs:
            print(f"Song ID: {song.song_id}")
            print(f"Lyrics: {song.lyrics}")
            print(f"Singer Name: {song.singer_name}")
            print()

    def displayByActor(self, singer_name):
        print(f"Songs by {singer_name}:")
        for song in self.songs:
            if song.singer_name.lower() == singer_name.lower():
                print(f"Song ID: {song.song_id}")
                print(f"Lyrics: {song.lyrics}")
                print(f"Singer Name: {song.singer_name}")
                print()

# Create an instance of the SongService class
song_service = SongService()

# Menu Interface
while True:
    print("\n-- Song Management System --")
    print("1. Add Song")
    print("2. Display All Songs")
    print("3. Display Songs by Singer")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        song_id = int(input("Enter Song ID: "))
        lyrics = input("Enter Lyrics: ")
        singer_name = input("Enter Singer Name: ")
        song_service.addsong(song_id, lyrics, singer_name)
        print("Song added successfully!")

    elif choice == "2":
        song_service.displayAllsongs()

    elif choice == "3":
        singer_name = input("Enter Singer Name: ")
        song_service.displayByActor(singer_name)

    elif choice == "4":
        print("Exiting the program...")
        break

    else:
        print("Invalid choice! Please try again.")
