"""
Q3. Write a python application to maintain information for xyz sports club. The
sports club wants to store employee details, for each employee store.
id, name, mobile no, emailid, Department, designation, Date of joining.
Employees are of 3 types salaried employee or contract employee,Vendors. If employee is salaried employee, then store basic salary, bonus and if it is contract employee then store no of hrs worked and per hour rate and if it is vendor then store no_of _employees, amount per employee
design a menu driven program to perform following
Calculate net salary by using following formula
1. Salaried Employee
Basic+DA+HRA-pf+bonus
DA-10% of basic
HRA – 15% of basic
Pf – 12% of Basic
2. Contract Employee
Hr rate * no of hrs worked
3 Vendor
Total_Amount=No of employees*amt
GST =18% Total_Amount
Net_amt= Total_Amount + GST
design a menu driven program to perform following
1. Display All employees (ask user salaried employee /contract employee /vendor display only one type of emplyees based on selection)
2. Search by id
3. Search by name
4. Display all employee
5. calculate salary and display for all emplyees with particular designation
6. accept department from user and display 5 employees of that department.
5. Exit

"""

class Employee:
    def __init__(self, id, name, mobile_no, email_id, department, designation, date_of_joining):
        self.id = id
        self.name = name
        self.mobile_no = mobile_no
        self.email_id = email_id
        self.department = department
        self.designation = designation
        self.date_of_joining = date_of_joining

class SalariedEmployee(Employee):
    def __init__(self, id, name, mobile_no, email_id, department, designation, date_of_joining, basic_salary, bonus):
        super().__init__(id, name, mobile_no, email_id, department, designation, date_of_joining)
        self.basic_salary = basic_salary
        self.bonus = bonus

    def calculate_net_salary(self):
        da = 0.1 * self.basic_salary
        hra = 0.15 * self.basic_salary
        pf = 0.12 * self.basic_salary
        net_salary = self.basic_salary + da + hra - pf + self.bonus
        return net_salary

class ContractEmployee(Employee):
    def __init__(self, id, name, mobile_no, email_id, department, designation, date_of_joining, hrs_worked, per_hour_rate):
        super().__init__(id, name, mobile_no, email_id, department, designation, date_of_joining)
        self.hrs_worked = hrs_worked
        self.per_hour_rate = per_hour_rate

    def calculate_net_salary(self):
        net_salary = self.hrs_worked * self.per_hour_rate
        return net_salary

class Vendor(Employee):
    def __init__(self, id, name, mobile_no, email_id, department, designation, date_of_joining, no_of_employees, amt_per_employee):
        super().__init__(id, name, mobile_no, email_id, department, designation, date_of_joining)
        self.no_of_employees = no_of_employees
        self.amt_per_employee = amt_per_employee

    def calculate_net_salary(self):
        total_amount = self.no_of_employees * self.amt_per_employee
        gst = 0.18 * total_amount
        net_salary = total_amount + gst
        return net_salary

class SportsClub:
    def __init__(self):
        self.employees = []

    def add_employee(self, employee):
        self.employees.append(employee)
        print("Employee added successfully!")

    def display_all_employees(self):
        print("All Employees:")
        for employee in self.employees:
            self.display_employee(employee)
            print()

    def search_by_id(self, id):
        for employee in self.employees:
            if employee.id == id:
                print("Employee found:")
                self.display_employee(employee)
                return
        print("Employee not found!")

    def search_by_name(self, name):
        found = False
        for employee in self.employees:
            if employee.name.lower() == name.lower():
                print("Employee found:")
                self.display_employee(employee)
                found = True
        if not found:
            print("Employee not found!")

    def display_by_designation(self, designation):
        found = False
        print(f"Employees with designation '{designation}':")
        for employee in self.employees:
            if employee.designation.lower() == designation.lower():
                self.display_employee(employee)
                found = True
        if not found:
            print("No employees found with the given designation.")

    def display_by_department(self, department):
        found = 0
        print(f"Employees in department '{department}':")
        for employee in self.employees:
            if employee.department.lower() == department.lower():
                self.display_employee(employee)
                found += 1
                if found == 5:
                    break
        if found == 0:
            print("No employees found in the given department.")

    def display_employee(self, employee):
        print(f"ID: {employee.id}")
        print(f"Name: {employee.name}")
        print(f"Mobile No: {employee.mobile_no}")
        print(f"Email ID: {employee.email_id}")
        print(f"Department: {employee.department}")
        print(f"Designation: {employee.designation}")
        print(f"Date of Joining: {employee.date_of_joining}")
        print()

# Create an instance of the SportsClub class
club = SportsClub()

# Accept employee details and store them in the club
while True:
    print("\n-- XYZ Sports Club --")
    print("1. Add Employee")
    print("2. Display All Employees")
    print("3. Search Employee by ID")
    print("4. Search Employee by Name")
    print("5. Display Employees by Designation")
    print("6. Display Employees by Department")
    print("7. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("Employee Types:")
        print("1. Salaried Employee")
        print("2. Contract Employee")
        print("3. Vendor")

        employee_type = input("Enter the employee type (1-3): ")

        id = input("Enter ID: ")
        name = input("Enter Name: ")
        mobile_no = input("Enter Mobile Number: ")
        email_id = input("Enter Email ID: ")
        department = input("Enter Department: ")
        designation = input("Enter Designation: ")
        date_of_joining = input("Enter Date of Joining: ")

        if employee_type == "1":
            basic_salary = float(input("Enter Basic Salary: "))
            bonus = float(input("Enter Bonus: "))
            employee = SalariedEmployee(id, name, mobile_no, email_id, department, designation, date_of_joining, basic_salary, bonus)
        elif employee_type == "2":
            hrs_worked = float(input("Enter Hours Worked: "))
            per_hour_rate = float(input("Enter Per Hour Rate: "))
            employee = ContractEmployee(id, name, mobile_no, email_id, department, designation, date_of_joining, hrs_worked, per_hour_rate)
        elif employee_type == "3":
            no_of_employees = int(input("Enter Number of Employees: "))
            amt_per_employee = float(input("Enter Amount per Employee: "))
            employee = Vendor(id, name, mobile_no, email_id, department, designation, date_of_joining, no_of_employees, amt_per_employee)
        else:
            print("Invalid employee type!")
            continue

        club.add_employee(employee)

    elif choice == "2":
        club.display_all_employees()

    elif choice == "3":
        id = input("Enter ID to search: ")
        club.search_by_id(id)

    elif choice == "4":
        name = input("Enter Name to search: ")
        club.search_by_name(name)

    elif choice == "5":
        designation = input("Enter Designation to search: ")
        club.display_by_designation(designation)

    elif choice == "6":
        department = input("Enter Department to search: ")
        club.display_by_department(department)

    elif choice == "7":
        print("Exiting the program...")
        break

    else:
        print("Invalid choice! Please try again.")
