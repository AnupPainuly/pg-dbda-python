"""
Q2. Accept lines from user and display only the lines that start with a number or any 2 alphabets
"""
# Function to filter lines that start with a number or any two alphabets
def filter_lines(lines):
    filtered_lines = []
    for line in lines:
        # Check if the line starts with a number or any two alphabets
        if line[0].isdigit() or (line[0].isalpha() and line[1].isalpha()):
            filtered_lines.append(line)
    return filtered_lines

# Function to accept lines from the user and filter them
def accept_lines():
    lines = []
    print("Enter lines (press Enter to stop):")
    while True:
        line = input()
        if line == "":
            break
        lines.append(line)

    filtered_lines = filter_lines(lines)  # Call the filter_lines function

    # Display the filtered lines
    print("\nFiltered lines:")
    for line in filtered_lines:
        print(line)

# Call the accept_lines function
accept_lines()