"""
Write a python program to accept user name and password and validate it. username should contain only alphabets or digits and password length should be 8, starts with alphabet and should contain at least one special character(#,@) .
accept username and password from user and validate it. if it is valid then display message welcome to our application. otherwise ask to re-enter.
(allows maximum 3 attempts to accept password)
"""

# Function to validate the username
def validate_username(username):
    if username.isalnum():  # Check if the username contains only alphabets or digits
        return True
    return False

# Function to validate the password
def validate_password(password):
    if len(password) == 8 and password[0].isalpha() and any(char in ['#', '@'] for char in password):
        # Check if the password has a length of 8, starts with an alphabet, and contains at least one special character (# or @)
        return True
    return False

# Main login function
def login():
    attempts = 0
    while attempts < 3:  # Allow maximum of 3 attempts
        username = input("Enter username: ")
        password = input("Enter password: ")

        if validate_username(username) and validate_password(password):  # Validate the username and password
            print("Welcome to our application!")
            return

        print("Invalid username or password. Please try again.")
        attempts += 1

    print("Maximum number of attempts reached. Exiting the program.")

# Call the login function
login()
