"""
Q1. write a regex to get only the part of the email before the "@" sign excluding the "@" sign.
example myemail@google.com o/p myemail
"""
import re

email = "myemail@google.com"

# Use regular expressions to extract the part before the "@" symbol
username = re.match(r"([^@]+)@", email).group(1)

# Print the extracted username
print(username)