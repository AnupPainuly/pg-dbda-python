"""
Write a python program to accept mobile number and validate it. it should contain exactly 10 digits.
"""

import re

def validate_mobile_number(mobile_number):
  """
  Validates a mobile number.

  Args:
    mobile_number: The mobile number to validate.

  Returns:
    True if the mobile number is valid, False otherwise.
  """

  # Check if the mobile number is of the correct length.
  if len(mobile_number) != 10:
    return False

  # Check if the mobile number contains only digits.
  if not re.match(r'^\d{10}$', mobile_number):
    return False

  return True

# Get the mobile number from the user.
mobile_number = input('Enter your mobile number: ')

# Validate the mobile number.
if validate_mobile_number(mobile_number):
  print('Valid mobile number.')
else:
  print('Invalid mobile number.')